# buzzer
A buzzer system implemented using websocket and node.js.
Supports up to 12 buzzers with different soundbytes.

Useful for quiz-style games - game host can connect as host (can enable and disable buzzers), and players can connect as individual buzzers using their smartphones.

Screenshot: http://i.imgur.com/pNPKCvm.jpg
